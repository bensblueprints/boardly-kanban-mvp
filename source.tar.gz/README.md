# 📋 Boardly

## Get the packaged app

Don't want to build from source? Get the signed installer, lifetime updates and setup support for a one-time payment at [onetimesuite.com/boardly](https://onetimesuite.com/boardly/) — same app, MIT source right here.

Part of [OneTimeSuite](https://onetimesuite.com) — pay-once alternatives to subscription software.

## Demo



https://github.com/user-attachments/assets/9d3890c6-d95c-4821-a269-4817140748fb



![MIT License](https://img.shields.io/badge/license-MIT-green.svg) ![Node 20+](https://img.shields.io/badge/node-20%2B-brightgreen) ![Self-hosted](https://img.shields.io/badge/self--hosted-yes-blue)

**The self-hosted Trello replacement. Pay once. Own it forever. No subscription.**

Trello charges **$5/user/month** — a 10-person team pays **$600 every year**, forever, for lists with cards on them. Boardly is the same kanban workflow running on *your* hardware: unlimited boards, unlimited "users" (it's your server), your data in a single SQLite file you can copy, back up, and export any time.

![Boardly screenshot](docs/screenshot.png)

## ✨ Features

- **Multiple boards** — color themes, emoji icons, star your favorites
- **Drag & drop everything** — reorder lists, drag cards between lists; order persists exactly
- **Rich cards** — markdown descriptions, due dates with overdue highlighting
- **Checklists** — with live progress bars on the card front
- **Labels** — colored, board-scoped, filterable
- **Attachments** — upload files straight onto cards, stored locally
- **Comments + activity log** — full history per card and per board
- **Filter & search** — by label, by due date (overdue / this week / none), full-text card search
- **Keyboard shortcuts** — `n` new card, `/` search
- **Export / import** — full-fidelity JSON round trip (including attachment bytes) for backup or moving boards between installs
- **Archive, don't delete** — cards and lists archive first and can be restored anytime
- **Talk to your board** — MCP server built in, so Claude (or any MCP client) can read and write your cards
- **Voice coach** — ask "what do I need to do next" and get a plan you can drop onto the card as a checklist, using a model on your own machine
- **100% local** — no telemetry, no external calls, no accounts

## 🚀 Quick start

```bash
npm i
npm run build
npm start        # → http://localhost:5315  (password: admin)
```

### 🖥️ Desktop app mode

Run it as a desktop app, or deploy to a $5 VPS when you need it public — same code, same data model:

```bash
npm run desktop  # Electron window, auto-logged-in, data in your OS user profile
```

Build a Windows installer with `npm run dist` (electron-builder, NSIS).

### 🐳 Docker / VPS

```bash
cp .env.example .env   # set ADMIN_PASSWORD!
docker compose up -d   # → port 5315, data persisted in a named volume
```

## ⚙️ Configuration

| Variable | Default | Purpose |
|---|---|---|
| `PORT` | `5315` | HTTP port |
| `ADMIN_PASSWORD` | `admin` | Sign-in password — change before going public |
| `DATA_DIR` | `./data` | SQLite db + attachment uploads |

## 🥊 Boardly vs Trello

| | **Boardly** | **Trello** |
|---|---|---|
| Price | **$19 once** | $5/user/**month** (Standard) |
| 10-person team, 3 years | **$19 total** | **$1,800** |
| Boards | Unlimited | Limited on free tier |
| Attachments | Your disk, your limits | 250 MB/file cap, plan-gated |
| Data ownership | SQLite file on your box | Atlassian's cloud |
| Works offline / air-gapped | ✅ | ❌ |
| Telemetry | None | Plenty |
| Export | Full-fidelity JSON, one click | JSON export is plan-gated |

## ☕ Skip the setup — get the 1-click installer

Don't want to touch a terminal? The packaged installer (plus updates and setup support) is a one-time **$19** on Whop:

**→ [https://whop.com/onetime-suite](https://whop.com/onetime-suite)**

The source here is MIT and always will be — the paid version is purely convenience.

## 🧱 Tech stack

- **Backend:** Node 20+, Express, better-sqlite3 (WAL mode), multer
- **Frontend:** React 18, Vite, Tailwind CSS 4, Framer Motion, @hello-pangea/dnd, Lucide icons, marked
- **Desktop:** Electron wrapper around the same Express server (electron-builder for NSIS installers)
- **Tests:** `npm test` boots the real server and runs 13 end-to-end API smoke checks

## 🧪 Verify

```bash
npm test
```

Covers: board/list/card CRUD, drag-move persistence, checklist progress, label filters, due-date filters, search, comments + activity, attachment byte-fidelity, archive/restore, and a full export→import deep-equal round trip.

## 🤖 AI integration (MCP)

Boardly speaks [Model Context Protocol](https://modelcontextprotocol.io), so an AI client can read and
write your boards — describe what's going on and let it create the cards. There are two ways in.

### From the desktop app (recommended)

Open **AI** in the header → **Start server**. Boardly serves MCP over HTTP from inside the running app on
a fixed loopback port (default `8765`), so the endpoint you configure once keeps working across restarts.
Then hit **Connect** for Claude Code or Claude Desktop and it writes the client config for you (keeping a
`.boardly-backup` of anything it replaced). Restart the client to pick it up.

- Bound to `127.0.0.1` only — never exposed to the network
- Every request needs `Authorization: Bearer <token>`; rotate the token any time from the same panel
- Stays enabled across restarts and autostarts with the app

To wire up any other client by hand:

```json
{
  "mcpServers": {
    "boardly": {
      "type": "http",
      "url": "http://127.0.0.1:8765/mcp",
      "headers": { "Authorization": "Bearer <token from Settings → AI>" }
    }
  }
}
```

### Standalone (stdio)

`mcp/server.js` is a stdio server for clients that spawn the process themselves. It opens the SQLite DB
directly, so it works whether or not the app is running (WAL mode makes concurrent access safe).

Data dir resolution: `BOARDLY_DATA_DIR` → `%APPDATA%\boardly\data` (desktop app) → `./data`.

```json
{
  "mcpServers": {
    "boardly": {
      "command": "node",
      "args": ["<repo>/mcp/server.js"],
      "env": { "BOARDLY_DATA_DIR": "C:\\Users\\<you>\\AppData\\Roaming\\boardly\\data" }
    }
  }
}
```

### Tools

Boards, lists, cards (create/update/move/delete), labels, checklists, comments and attachments —
including `attach_link`, which attaches a local file path or URL as a small `.url` shortcut so linking a
200 MB installer costs a couple of hundred bytes.

`find_cards` and `get_card` let a client search the board and pull one card in full — description,
checklists, comments, attachments — so it can read before it writes instead of guessing.

Both transports share one implementation (`mcp/tools.js`). Tests use throwaway data dirs and never touch
your real boards:

```bash
npm run test:mcp        # stdio round trip
npm run test:mcp-http   # in-app HTTP: auth, token rotation, restart persistence
npm run test:all        # everything
```

## 🎙️ Voice coach — "what do I need to do next?"

MCP lets *your* AI client drive Boardly. The coach is the other direction: a panel inside Boardly that
looks at your board and tells you what to work on next, one thing at a time.

Open a board → **What's next**. Type or hold the mic, ask, and you get back a concrete plan you can push
onto the card as a real checklist with one click. It reads your answer aloud too.

It talks to any **OpenAI-compatible** server, so point it at whatever you already run:

| Setting | Example | Notes |
|---|---|---|
| Model server URL | `http://192.168.1.10:11434/v1` | Ollama, vLLM, LM Studio, llama.cpp — or an OpenAI-compatible cloud endpoint |
| Model | picked from a live dropdown | falls back to a text box if the server won't list models |
| Speech-to-text URL | `http://192.168.1.10:8178/v1` | optional; any server exposing `/v1/audio/transcriptions` (e.g. faster-whisper) |

Nothing is configured out of the box and nothing is sent anywhere until you fill these in. Point them at a
box on your own network and the whole loop — board, model, transcription — stays in your house.

**Why it doesn't hallucinate your board.** A small local model handed a whole board will confidently invent
a card that doesn't exist. So Boardly picks the card in *code* (most-nearly-done first, finished cards
excluded) and sends only that one card's brief to the model — description, every checklist with its done
state, recent comments, attachment names. The card the plan attaches to is therefore always one of yours.
Output is constrained with `response_format: json_schema`, degrading to `json_object` and then to plain
text for servers that don't support it.

The **Test** button probes whatever is currently typed in the boxes and tells you what's actually wrong —
"nothing is listening on host:port", "that hostname doesn't resolve" — instead of `fetch failed`.

```bash
npm run test:coach      # 21 tests, all against a stub server — no model required
```

## Uploads

Attachments are capped at 25 MB by default. The desktop build raises this to 4 GB (it's a local app
writing to your own disk); override either with `MAX_UPLOAD_MB`.

## License

MIT © 2026 Ben (bensblueprints)
